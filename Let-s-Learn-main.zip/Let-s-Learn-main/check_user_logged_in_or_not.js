let current_user = JSON.parse(localStorage.getItem('user'));

if(!current_user){
    // window.location.assign('index.html');
}else{
    window.location.assign('Home.html');
}